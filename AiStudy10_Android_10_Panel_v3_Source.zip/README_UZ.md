# AiStudy10 Android — 10 panel (tajriba versiyasi)

**Asos:** foydalanuvchi yuborgan AiStudy10 v2.17 Windows dasturi. Android kodi yangidan tuzilgan; Electron fayllari Androidda ishlamaydi.

## Texnologiya

GeckoView 160 orqali `GeckoSessionSettings.contextId("aistudy-profile-N")` bilan 10 mustaqil login konteksti. Har bir profilning cookie va localStorage ma'lumotlari ajralgan. Barcha sessiyalar ochiq; `10 panel` rejimi 2 ustunda 5 qator ko‘rinadi, `1 panel` rejimida tanlangan sessiya to‘liq ochiladi.

Bundled WebExtension `app/src/main/assets/aistudy/` ichida. Faqat `https://omp.aistudy.uz` sahifalarida ishlaydi. Login va parollar dastur kodiga saqlanmaydi.

## Funksiyalar

- 10 ta sessiya; bitta/10 panel rejimi (telefon ekranida 10 panel mayda ko‘rinadi)
- HTML5 video 1/1.5/2/3×, avtomatik ijro imkoniyati
- Dars tugaganda keyingi ko‘rilmagan darsni topib bosishga urinish; ko‘rilmagan avvalgi darsga qaytish
- Video ijro vaqtini mahalliy saqlash, ulanish tiklanganda qayta yuklashga urinish
- Test boshlash, javoblar bazasi, ixtiyoriy taxminiy variant, avtomatik yakunlash (faqat sozlamada yoqilganda)
- Keyingi kursga o‘tish va "Hozir boshlash" tugmalarini tanishga urinish
- Fon rejimi uchun notificationli xizmat. **Bu Android o‘chirilgan ekranda 10 video doim ishlashini kafolatlamaydi!**
- Muallif: Akmal Muxamedjanov

## APK yig‘ish

Repozitoriyning ildizida shu fayllar bo‘lsin. GitHub → Actions → "AiStudy10 Android 10-Panel APK" → Run workflow. Yashil yakunlangach, Artifacts → `AiStudy10-Android10-APK` → `app-debug.apk` ni oling. Yoki Android SDK/JDK o‘rnatilgan kompyuterda `gradle :app:assembleDebug`.

## Sinov holati va cheklovlar

* Kod sintaksisi va loyiha strukturasining statik tekshiruvlari o'tkazilgan, **Android telefonida va autentifikatsiyadan keyingi real omp.aistudy.uz sahifalarida sinov bo‘lmagan**.
* GeckoView kutubxonasi yirik: APK hajmi katta bo‘lishi va 10 ta bir vaqtdagi video juda ko‘p RAM/batareya ishlatishi mumkin.
* Telefon fon cheklovlari va saytning avtomatik ijro/server tasdiqlash qoidalari avtomatlashtirishga to'sqinlik qilishi mumkin.
* Mobil ilova Windows dasturi bilan bir xil binar yoki to‘liq funksional ekvivalent emas. Dizayn va tanish funksiyalar ko‘chirildi.
* Taxminiy javoblar noto‘g‘ri bo‘lishi mumkin. Faqat foydalanishga vakolatingiz bor akkauntlarni ishlating.
